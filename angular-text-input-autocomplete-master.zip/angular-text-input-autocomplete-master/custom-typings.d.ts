declare module 'fork-ts-checker-webpack-plugin';
declare module 'webpack-angular-externals';
declare module 'webpack-rxjs-externals';
declare module 'webpack-config-utils';
declare module 'offline-plugin';
declare module '@mattlewis92/webpack-karma-die-hard';
declare module 'textarea-caret';
declare module 'keyboardevent-key-polyfill';