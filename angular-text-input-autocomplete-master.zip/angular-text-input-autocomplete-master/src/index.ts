export * from './text-input-autocomplete.module';
export {
  TextInputAutocompleteMenuComponent
} from './text-input-autocomplete-menu.component';
